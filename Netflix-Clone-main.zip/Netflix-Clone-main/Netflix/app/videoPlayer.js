const videoId = localStorage.getItem("id");
const videoDetails = JSON.parse(localStorage.getItem(`${videoId}`));
const videoPlayer = document.querySelector(".mainPlayer");
const mainDiv = document.querySelector(".mainDiv");
const controllerBtn = document.querySelectorAll(".controller-btn");
const movieTitle = document.querySelector(".movie-title");
const imgPlayPause = document.querySelector(".img-play-pause");
let progress = document.querySelector(".progress");
let textDuration = document.querySelector(".text-duration");
let imgEpisodes = document.querySelector(".img-episodes");
let imgNextEp = document.querySelector(".img-next-ep");
let imgIncreaseTenSec = document.querySelector(".img-increase-ten-sec");
let imgDecreaseTenSec = document.querySelector(".img-decrease-ten-sec");
let imgBack = document.querySelector(".img-back");
let imgVolume = document.querySelector(".img-volume");
let imgFullScreen = document.querySelector(".img-full-screen");
let seekbar_volume = document.querySelector(".seek_volume");
let img_episodes = document.querySelector(".img-episodes");
let episodes_container = document.querySelector(".episodes-container");

const div_video_seek_container = document.querySelector(
  ".div_video_seek_container"
);
movieTitle.textContent = videoDetails.title;
videoPlayer.src = videoDetails.videoUrl;
let videoDuration = videoDetails.duration;
let currentEpIndex = videoDetails.episodeIndex;

seekbar_volume.value = videoPlayer.volume * 100;

videoPlayer.currentTime = videoDuration;
if (videoDetails.isSeason != true) {
  imgNextEp.style.display = "none";
  imgEpisodes.style.display = "none";
} else {
  const videoEpSrc = JSON.parse(videoDetails.otherEpisodes);
  if (currentEpIndex === videoEpSrc.length - 1) {
    imgNextEp.style.display = "none";
  } else {
    imgNextEp.style.display = "block";
    imgEpisodes.style.display = "block";
  }
}

mainDiv.addEventListener("mouseover", () => {
  mainDiv.style.opacity = "1";
});
mainDiv.addEventListener("mouseout", () => {
  mainDiv.style.opacity = "0";
});

imgPlayPause.addEventListener("click", () => {
  if (videoPlayer.paused) {
    videoPlayer.play();
    imgPlayPause.src = "../Assets/Images/pause.png";
    console.log("Video Is Paused");
  } else {
    videoPlayer.pause();
    imgPlayPause.src = "../Assets/Images/play.png";
  }
});

document.addEventListener("keypress", (e) => {
  if (e.key == " ") {
    if (videoPlayer.paused) {
      videoPlayer.play();
      imgPlayPause.src = "../Assets/Images/pause.png";
      console.log("Video Is Paused");
    } else {
      videoPlayer.pause();
      imgPlayPause.src = "../Assets/Images/play.png";
    }
  }
});

progress.addEventListener("change", () => {
  videoPlayer.currentTime = videoPlayer.duration * (progress.value / 100);
});

videoPlayer.addEventListener("timeupdate", () => {
  progress.value = videoPlayer.currentTime * (100 / videoPlayer.duration);

  setTimeout(() => {
    videoDetails.duration = videoPlayer.duration * (progress.value / 100);
    localStorage.setItem(videoId, JSON.stringify(videoDetails));
  }, 2000);
  getDuration();
});

imgDecreaseTenSec.addEventListener("click", () => {
  videoPlayer.currentTime = videoPlayer.currentTime - 10;
});

imgIncreaseTenSec.addEventListener("click", () => {
  videoPlayer.currentTime = videoPlayer.currentTime + 10;
});

imgBack.addEventListener("click", () => {
  location.href = "../screens/home.html";
});

imgFullScreen.addEventListener("click", () => {
  openFullscreen();
});

function openFullscreen() {
  if (videoPlayer.requestFullscreen) {
    videoPlayer.requestFullscreen();
  } else if (videoPlayer.webkitRequestFullscreen) {
    /* Safari */
    videoPlayer.webkitRequestFullscreen();
  } else if (videoPlayer.msRequestFullscreen) {
    /* IE11 */
    videoPlayer.msRequestFullscreen();
  }
}

function getDuration() {
  if (videoPlayer.readyState > 0) {
    textDuration.textContent = `${Math.floor(
      videoPlayer.duration / 3600
    )}:${Math.floor((videoPlayer.duration / 60) % 60)}:${Math.floor(
      videoPlayer.duration % 60
    )}`;
  }
}

imgNextEp.addEventListener("click", () => {
  currentEpIndex++;
  const videoSrc = JSON.parse(videoDetails.otherEpisodes);
  videoPlayer.src = videoSrc[currentEpIndex].videoUrl;
  videoDetails.videoUrl = videoSrc[currentEpIndex].videoUrl;
  videoDetails.episodeIndex = currentEpIndex;
  localStorage.setItem(videoId, JSON.stringify(videoDetails));
  if (currentEpIndex === videoSrc.length - 1) {
    imgNextEp.style.display = "none";
  }
});

window.addEventListener("beforeunload", () => {
  localStorage.removeItem("id");
});

div_video_seek_container.addEventListener("mouseover", () => {
  div_video_seek_container.classList.add("div_video_seek_container_show");
});
div_video_seek_container.addEventListener("mouseout", () => {
  div_video_seek_container.classList.remove("div_video_seek_container_show");
});
imgVolume.addEventListener("mouseover", () => {
  div_video_seek_container.classList.add("div_video_seek_container_show");
});
imgVolume.addEventListener("mouseout", () => {
  div_video_seek_container.classList.remove("div_video_seek_container_show");
});

seekbar_volume.addEventListener("change", (e) => {
  videoPlayer.volume = e.target.value / 100;
});

img_episodes.addEventListener("mouseover", () => {
  episodes_container.classList.add("episodes-container-anim");
});

img_episodes.addEventListener("mouseout", () => {
  episodes_container.classList.remove("episodes-container-anim");
});
episodes_container.addEventListener("mouseover", () => {
  episodes_container.classList.add("episodes-container-anim");
});

episodes_container.addEventListener("mouseout", () => {
  episodes_container.classList.remove("episodes-container-anim");
});

function getOtherVideos() {}
