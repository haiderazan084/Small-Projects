const users = [
  { email: "developers@gmail.com", password: "ewtwetfgd" },
  { email: "abcdef@gmail.com", password: "drutrtrgjda" },
  { email: "temp@gmail.com", password: "fsdfsdasdas" },
  { email: "development@gmail.com", password: "passwordasd" },
  { email: "ddr@gmail.com", password: "sdfsdfasdas" },
  { email: "hello@gmail.com", password: "sdfsdfdssda" },
  { email: "admin@gmail.com", password: "klsdjajdlassdass" },
  { email: "admin2@gmail.com", password: "asdasdsadaasd" },
];

if (localStorage.getItem("isLogin") == "true") {
  window.location = "../screens/home.html";
}

let inputEmail = document.querySelector("#inputEmail");
let labelEmail = document.querySelector("#labelEmail");

let inputPassword = document.querySelector("#inputPassword");
let labelPasswrd = document.querySelector("#labelPasswrd");
let labelShow = document.querySelector("#labelShow");
let checkboxRemember = document.querySelector("#checkboxRemember");

// Error Messages
let divErrorEmail = document.querySelector("#divErrorEmail");
let divErrorPassword = document.querySelector("#divErrorPassword");
let btnSignIn = document.querySelector("#btnSignIn");

let password = true;
let showHovered = false;
let rememberMe = true;
inputEmail.addEventListener("focus", () => {
  labelEmail.classList.add("labelEmail-focused");
  inputEmail.classList.add("inputs-focused");
});

inputEmail.addEventListener("blur", () => {
  if (inputEmail.value === "") {
    labelEmail.classList.remove("labelEmail-focused");
  }
  inputEmail.classList.remove("inputs-focused");

  if (inputEmail.value === "" || inputEmail.value.length < 5) {
    divErrorEmail.style.display = "block";
    inputEmail.classList.add("emailError");
  } else {
    divErrorEmail.style.display = "none";
    inputEmail.classList.remove("emailError");
  }
});

labelShow.addEventListener("mouseover", () => {
  showHovered = true;
});
labelShow.addEventListener("mouseout", () => {
  showHovered = false;
});

labelShow.addEventListener("click", () => {
  if (password) {
    inputPassword.focus();
    labelShow.textContent = "HIDE";
    password = false;
    inputPassword.type = "text";
  } else {
    password = true;
    inputPassword.focus();
    inputPassword.type = "password";
    labelShow.textContent = "SHOW";
  }
});

inputPassword.addEventListener("focus", () => {
  labelShow.style.visibility = "visible";
  labelPasswrd.classList.add("labelPasswrd-focused");
  inputPassword.classList.add("inputs-focused");
});

inputPassword.addEventListener("blur", () => {
  if (!showHovered) {
    labelShow.style.visibility = "hidden";

    if (inputPassword.value === "") {
      labelPasswrd.classList.remove("labelPasswrd-focused");
    }
    inputPassword.classList.remove("inputs-focused");
  }

  if (inputPassword.value === "" || inputPassword.value.length <= 8) {
    divErrorPassword.style.display = "block";
    inputPassword.classList.add("passwordError");
  } else {
    divErrorPassword.style.display = "none";
    inputPassword.classList.remove("passwordError");
  }
});

inputEmail.addEventListener("input", (e) => {
  if (e.target.value.length > 4) {
    divErrorEmail.style.display = "none";
    inputEmail.classList.remove("emailError");
  } else {
    divErrorEmail.style.display = "block";
    inputEmail.classList.add("emailError");
  }
});

inputPassword.addEventListener("input", (e) => {
  if (e.target.value.length > 16 || e.target.value.length < 8) {
    divErrorPassword.style.display = "block";
    inputPassword.classList.add("passwordError");
  } else {
    divErrorPassword.style.display = "none";
    inputPassword.classList.remove("passwordError");
  }
});

btnSignIn.addEventListener("click", () => {
  if (
    !inputEmail.value.length < 5 ||
    !inputPassword.value.length < 8 ||
    !inputPassword.value.length > 16
  ) {
    // Login Account
    LoginAccount();
  }
});

checkboxRemember.addEventListener("change", (e) => {
  if (e.target.checked) {
    rememberMe = true;
  } else {
    rememberMe = false;
  }
});

function LoginAccount() {
  users.find((x) => {
    if (x.email === inputEmail.value && x.password === inputPassword.value) {
      if (rememberMe) {
        localStorage.setItem("isLogin", "true");
        localStorage.setItem("email", x.email);
        localStorage.setItem("password", x.password);
        window.location = "../screens/home.html";
      } else {
        localStorage.setItem("isLogin", "default");
        localStorage.setItem("email", x.email);
        localStorage.setItem("password", x.password);
        window.location = "../screens/home.html";
      }
    }
  });
}
