if (
  localStorage.getItem("isLogin") === "true" ||
  localStorage.getItem("isLogin") === "default"
) {
} else {
  window.location = "../screens/login.html";
}
