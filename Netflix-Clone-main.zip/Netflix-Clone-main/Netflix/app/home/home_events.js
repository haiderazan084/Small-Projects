let header = document.querySelector(".header");
let avatar = document.querySelector(".avatar");
let imgArrow = document.querySelector(".img-arrow");

// For Scroll Horizontal Buttons
let imgArrowNext = document.querySelectorAll(".img-arrows-next");
let imgArrowBack = document.querySelectorAll(".img-arrows-back");

let VideosListDiv = document.querySelectorAll(".video-list-div");
let textExploreAll = document.querySelectorAll(".explore-all");
let imgArrowTitle = document.querySelectorAll(".img-arrow-title");
let textHeadings = document.querySelectorAll(".text-headings");
let pop_top_header = document.querySelector(".pop-top-header");

avatar.addEventListener("mouseover", (e) => {
  imgArrow.classList.add("img-arrow-transform");
  pop_top_header.classList.add("pop-top-header-animate");
});
avatar.addEventListener("mouseout", (e) => {
  imgArrow.classList.remove("img-arrow-transform");
  pop_top_header.classList.remove("pop-top-header-animate");
});
pop_top_header.addEventListener("mouseover", (e) => {
  imgArrow.classList.add("img-arrow-transform");
  pop_top_header.classList.add("pop-top-header-animate");
});
pop_top_header.addEventListener("mouseout", (e) => {
  imgArrow.classList.remove("img-arrow-transform");
  pop_top_header.classList.remove("pop-top-header-animate");
});
imgArrow.addEventListener("mouseover", (e) => {
  imgArrow.classList.add("img-arrow-transform");
  pop_top_header.classList.add("pop-top-header-animate");
});
imgArrow.addEventListener("mouseout", (e) => {
  imgArrow.classList.remove("img-arrow-transform");
  pop_top_header.classList.remove("pop-top-header-animate");
});
window.addEventListener("scroll", (e) => {
  if (window.scrollY > 2) {
    header.classList.add("header-scrolled");
  } else {
    header.classList.remove("header-scrolled");
  }
});

imgArrowBack.forEach((items, index, array) => {
  items.addEventListener("click", (e) => {
    VideosListDiv[index].style.scrollBehavior = "smooth";
    VideosListDiv[index].scrollLeft -= 600;
  });
});

imgArrowNext.forEach((item, index) => {
  item.addEventListener("click", (e) => {
    VideosListDiv[index].style.scrollBehavior = "smooth";
    VideosListDiv[index].scrollLeft += 600;
  });
});

textHeadings.forEach((items, index) => {
  items.addEventListener("mouseover", (e) => {
    textExploreAll[index].classList.add("explore-all-animate");
    imgArrowTitle[index].classList.add("img-arrow-animate");
  });

  items.addEventListener("mouseout", (e) => {
    textExploreAll[index].classList.remove("explore-all-animate");
    imgArrowTitle[index].classList.remove("img-arrow-animate");
  });
});

textExploreAll.forEach((items, index) => {
  items.addEventListener("mouseover", (e) => {
    textExploreAll[index].classList.add("explore-all-animate");
    imgArrowTitle[index].classList.add("img-arrow-animate");
  });

  items.addEventListener("mouseout", (e) => {
    textExploreAll[index].classList.remove("explore-all-animate");
    imgArrowTitle[index].classList.remove("img-arrow-animate");
  });
});
