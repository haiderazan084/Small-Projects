let imgSoundBg = document.querySelector(".img-sound-bg");
let background = document.querySelector(".background");

let muteBg = true;
background.muted = true;
if (
  localStorage.getItem("isLogin") === "true" ||
  localStorage.getItem("isLogin") === "default"
) {
} else {
  window.location = "../screens/login.html";
}

// To Animate Options Menu
imgSoundBg.addEventListener("click", (e) => {
  if (muteBg) {
    muteBg = false;
    imgSoundBg.src = "../Assets/Images/un-mute.png";
    background.muted = false;
  } else {
    muteBg = true;
    imgSoundBg.src = "../Assets/Images/muted.png";
    background.muted = true;
  }
});

// To Create PlayLists

playlists.forEach((playListItem, indexPlaylist) => {
  CreateRows(playListItem.title);
  playListItem.videos.forEach((items, index) => {
    CreateVideoItems(
      items.title,
      items.thumbnailUrl,
      items.id,
      items.videoUrl,
      items.season,
      items.otherEpisodes,
      indexPlaylist,
      playListItem.class
    );
  });
});

function CreateRows(titles, playlist) {
  const section = document.querySelector(".section2");

  const columnRecomendedDiv = document.createElement("DIV");
  columnRecomendedDiv.classList.add("columns-recommended");

  const titleDiv = document.createElement("DIV");
  titleDiv.classList.add("title-div");

  const textHeadings = document.createElement("P");
  textHeadings.classList.add("text-headings");
  textHeadings.innerText = titles;

  const textExploreAll = document.createElement("P");
  textExploreAll.classList.add("explore-all");
  textExploreAll.innerText = "Explore All";

  const imgArrow = document.createElement("IMG");
  imgArrow.classList.add("img-arrow-title");
  imgArrow.src = "../Assets/Images/left-arrow-white.png";

  const mainColumnsDiv = document.createElement("DIV");
  mainColumnsDiv.classList.add("main-columns-div");

  const imgArrowBack = document.createElement("IMG");
  imgArrowBack.classList.add("img-arrows-back");
  imgArrowBack.classList.add("img-arrow-scrollers");
  imgArrowBack.src = "../Assets/Images/left-arrow-white.png";

  const VideoListDiv = document.createElement("DIV");
  VideoListDiv.classList.add("video-list-div");

  const VideosList = document.createElement("UL");
  VideosList.classList.add("videos-list");

  const imgArrowNext = document.createElement("IMG");
  imgArrowNext.classList.add("img-arrow-scrollers");
  imgArrowNext.classList.add("img-arrows-next");
  imgArrowNext.src = "../Assets/Images/right-arrow-white.png";

  section.appendChild(columnRecomendedDiv);

  columnRecomendedDiv.appendChild(titleDiv);
  columnRecomendedDiv.appendChild(mainColumnsDiv);

  titleDiv.appendChild(textHeadings);
  titleDiv.appendChild(textExploreAll);
  titleDiv.appendChild(imgArrow);

  mainColumnsDiv.appendChild(imgArrowBack);
  mainColumnsDiv.appendChild(imgArrowNext);
  mainColumnsDiv.appendChild(VideoListDiv);

  VideoListDiv.appendChild(VideosList);
}

function CreateVideoItems(
  title,
  thumbnailUrl,
  id,
  video,
  season,
  otherEpisodes,
  index,
  playlistClass
) {
  const videoUl = document.querySelectorAll(".videos-list");
  const li = document.createElement("LI");
  li.id = id;
  li.classList.add("videos-items");
  const div = document.createElement("DIV");
  div.classList.add("videos-items-list-div");

  const image = document.createElement("img");
  image.className = "img_thumbnail";
  image.src = thumbnailUrl;
  videoUl[index].appendChild(li);
  li.appendChild(div);
  div.appendChild(image);

  li.addEventListener("click", () => {
    const data = localStorage.getItem(id);
    if (season === true) {
      if (data == null) {
        const videoDetails = {
          title: title,
          videoUrl: otherEpisodes[0].videoUrl,
          isSeason: season,
          id: id,
          duration: 0,
          episodeIndex: 0,
          class: playlistClass,
          otherEpisodes: JSON.stringify(otherEpisodes),
        };
        localStorage.setItem("id", id);
        localStorage.setItem(id, JSON.stringify(videoDetails));
        window.location.href = "../screens/videoPlayer.html";
      } else {
        localStorage.setItem("id", id);
        window.location.href = "../screens/videoPlayer.html";
      }
    } else {
      if (data == null) {
        const videoDetails = {
          title: title,
          videoUrl: video,
          isSeason: season,
          id: id,
          duration: 0,
          otherEpisodes: "No Episode",
          class: playlistClass,
        };
        localStorage.setItem("id", id);
        localStorage.setItem(id, JSON.stringify(videoDetails));
        window.location.href = "../screens/videoPlayer.html";
      } else {
        localStorage.setItem("id", id);
        window.location.href = "../screens/videoPlayer.html";
      }
    }
  });
}
