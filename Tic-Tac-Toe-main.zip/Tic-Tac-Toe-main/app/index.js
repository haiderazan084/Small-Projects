const btn_symbol = document.querySelectorAll(".btn_symbol");
const dialog = document.querySelector(".dialog");
const win_dialog = document.querySelector(".win_dialog");
const win_msg = document.querySelector(".win_msg");
const btn_restart = document.querySelector(".btn_restart");
const buttons_input = document.querySelectorAll(".buttons_input");
let your_symbol = "";
let cpu_symbol = "";
let btn_enable = true;
let current_player = your_symbol;
let used_btn_idexes = [];
let cputime;

buttons_input.forEach((items, index) => {
  items.addEventListener("click", () => {
    if (localStorage.getItem("type") == "easy") {
      if (!used_btn_idexes.includes(index)) {
        if (btn_enable) {
          current_player = your_symbol;
          items.textContent = your_symbol;
          used_btn_idexes.push(index);
          btn_enable = false;
          Win(items);
          cputime = setTimeout(() => {
            current_player = cpu_symbol;
            computerResponse(items);
          }, 500);
        }
      }
    } else {
      if (!used_btn_idexes.includes(index)) {
        if (btn_enable) {
          items.textContent = your_symbol;
          used_btn_idexes.push(index);
          current_player = cpu_symbol;
          btn_enable = false;
          setTimeout(() => {
            PlayCpuHardly(items);
            current_player = your_symbol;
          }, 500);
        }
      }
    }
  });
});

function PlayCpuHardly(items) {
  if (
    buttons_input[0].textContent == cpu_symbol &&
    buttons_input[1].textContent == cpu_symbol &&
    buttons_input[2].textContent == ""
  ) {
    buttons_input[2].textContent = cpu_symbol;
    btn_enable = true;
    used_btn_idexes.push(2);
  } else {
    if (
      buttons_input[1].textContent == cpu_symbol &&
      buttons_input[2].textContent == cpu_symbol &&
      buttons_input[0].textContent == ""
    ) {
      buttons_input[0].textContent = cpu_symbol;
      btn_enable = true;
      used_btn_idexes.push(0);
      YouWinDialog(false);
    } else {
      if (
        buttons_input[0].textContent == cpu_symbol &&
        buttons_input[2].textContent == cpu_symbol &&
        buttons_input[1].textContent == ""
      ) {
        buttons_input[1].textContent = cpu_symbol;
        btn_enable = true;
        used_btn_idexes.push(1);
        YouWinDialog(false);
      } else {
        if (
          buttons_input[3].textContent == cpu_symbol &&
          buttons_input[4].textContent == cpu_symbol &&
          buttons_input[5].textContent == ""
        ) {
          buttons_input[5].textContent = cpu_symbol;
          btn_enable = true;
          used_btn_idexes.push(5);
          YouWinDialog(false);
        } else {
          if (
            buttons_input[3].textContent == "" &&
            buttons_input[4].textContent == cpu_symbol &&
            buttons_input[5].textContent == cpu_symbol
          ) {
            buttons_input[3].textContent = cpu_symbol;
            btn_enable = true;
            used_btn_idexes.push(3);
            YouWinDialog(false);
          } else {
            if (
              buttons_input[3].textContent == cpu_symbol &&
              buttons_input[4].textContent == "" &&
              buttons_input[5].textContent == cpu_symbol
            ) {
              buttons_input[4].textContent = cpu_symbol;
              btn_enable = true;
              used_btn_idexes.push(4);
              YouWinDialog(false);
            } else {
              if (
                buttons_input[6].textContent == cpu_symbol &&
                buttons_input[7].textContent == cpu_symbol &&
                buttons_input[8].textContent == ""
              ) {
                buttons_input[8].textContent = cpu_symbol;
                btn_enable = true;
                used_btn_idexes.push(8);
                YouWinDialog(false);
              } else {
                if (
                  buttons_input[7].textContent == cpu_symbol &&
                  buttons_input[8].textContent == cpu_symbol &&
                  buttons_input[6].textContent == ""
                ) {
                  buttons_input[6].textContent = cpu_symbol;
                  btn_enable = true;
                  used_btn_idexes.push(6);
                  YouWinDialog(false);
                } else {
                  if (
                    buttons_input[6].textContent == cpu_symbol &&
                    buttons_input[7].textContent == "" &&
                    buttons_input[8].textContent == cpu_symbol
                  ) {
                    buttons_input[7].textContent = cpu_symbol;
                    btn_enable = true;
                    used_btn_idexes.push(7);
                    YouWinDialog(false);
                  } else {
                    if (
                      buttons_input[0].textContent == cpu_symbol &&
                      buttons_input[3].textContent == cpu_symbol &&
                      buttons_input[6].textContent == ""
                    ) {
                      buttons_input[6].textContent = cpu_symbol;
                      btn_enable = true;
                      used_btn_idexes.push(6);
                      YouWinDialog(false);
                    } else {
                      if (
                        buttons_input[0].textContent == "" &&
                        buttons_input[3].textContent == cpu_symbol &&
                        buttons_input[6].textContent == cpu_symbol
                      ) {
                        buttons_input[0].textContent = cpu_symbol;
                        btn_enable = true;
                        used_btn_idexes.push(0);
                        YouWinDialog(false);
                      } else {
                        if (
                          buttons_input[0].textContent == cpu_symbol &&
                          buttons_input[6].textContent == cpu_symbol &&
                          buttons_input[3].textContent == ""
                        ) {
                          buttons_input[3].textContent = cpu_symbol;
                          btn_enable = true;
                          used_btn_idexes.push(3);
                          YouWinDialog(false);
                        } else {
                          if (
                            buttons_input[1].textContent == cpu_symbol &&
                            buttons_input[4].textContent == cpu_symbol &&
                            buttons_input[7].textContent == ""
                          ) {
                            buttons_input[7].textContent = cpu_symbol;
                            btn_enable = true;
                            used_btn_idexes.push(7);
                            YouWinDialog(false);
                          } else {
                            if (
                              buttons_input[1].textContent == "" &&
                              buttons_input[4].textContent == cpu_symbol &&
                              buttons_input[7].textContent == cpu_symbol
                            ) {
                              buttons_input[1].textContent = cpu_symbol;
                              btn_enable = true;
                              used_btn_idexes.push(1);
                              YouWinDialog(false);
                            } else {
                              if (
                                buttons_input[1].textContent == cpu_symbol &&
                                buttons_input[4].textContent == "" &&
                                buttons_input[7].textContent == cpu_symbol
                              ) {
                                buttons_input[4].textContent = cpu_symbol;
                                btn_enable = true;
                                used_btn_idexes.push(4);
                                YouWinDialog(false);
                              } else {
                                if (
                                  buttons_input[2].textContent == "" &&
                                  buttons_input[5].textContent == cpu_symbol &&
                                  buttons_input[8].textContent == cpu_symbol
                                ) {
                                  buttons_input[2].textContent = cpu_symbol;
                                  btn_enable = true;
                                  used_btn_idexes.push(2);
                                  YouWinDialog(false);
                                } else {
                                  if (
                                    buttons_input[2].textContent ==
                                      cpu_symbol &&
                                    buttons_input[5].textContent ==
                                      cpu_symbol &&
                                    buttons_input[8].textContent == ""
                                  ) {
                                    buttons_input[8].textContent = cpu_symbol;
                                    btn_enable = true;
                                    used_btn_idexes.push(8);
                                    YouWinDialog(false);
                                  } else {
                                    if (
                                      buttons_input[2].textContent ==
                                        cpu_symbol &&
                                      buttons_input[5].textContent == "" &&
                                      buttons_input[8].textContent == cpu_symbol
                                    ) {
                                      buttons_input[5].textContent = cpu_symbol;
                                      btn_enable = true;
                                      used_btn_idexes.push(8);
                                      YouWinDialog(false);
                                    } else {
                                      if (
                                        buttons_input[0].textContent ==
                                          cpu_symbol &&
                                        buttons_input[4].textContent ==
                                          cpu_symbol &&
                                        buttons_input[8].textContent == ""
                                      ) {
                                        buttons_input[8].textContent =
                                          cpu_symbol;
                                        btn_enable = true;
                                        used_btn_idexes.push(8);
                                        YouWinDialog(false);
                                      } else {
                                        if (
                                          buttons_input[0].textContent == "" &&
                                          buttons_input[4].textContent ==
                                            cpu_symbol &&
                                          buttons_input[8].textContent ==
                                            cpu_symbol
                                        ) {
                                          buttons_input[0].textContent =
                                            cpu_symbol;
                                          btn_enable = true;
                                          used_btn_idexes.push(0);
                                          YouWinDialog(false);
                                        } else {
                                          if (
                                            buttons_input[0].textContent ==
                                              cpu_symbol &&
                                            buttons_input[4].textContent ==
                                              "" &&
                                            buttons_input[8].textContent ==
                                              cpu_symbol
                                          ) {
                                            buttons_input[4].textContent =
                                              cpu_symbol;
                                            btn_enable = true;
                                            used_btn_idexes.push(4);
                                            YouWinDialog(false);
                                          } else {
                                            if (
                                              buttons_input[2].textContent ==
                                                "" &&
                                              buttons_input[4].textContent ==
                                                cpu_symbol &&
                                              buttons_input[6].textContent ==
                                                cpu_symbol
                                            ) {
                                              buttons_input[2].textContent =
                                                cpu_symbol;
                                              btn_enable = true;
                                              used_btn_idexes.push(2);
                                              YouWinDialog(false);
                                            } else {
                                              if (
                                                buttons_input[2].textContent ==
                                                  cpu_symbol &&
                                                buttons_input[4].textContent ==
                                                  cpu_symbol &&
                                                buttons_input[6].textContent ==
                                                  ""
                                              ) {
                                                buttons_input[6].textContent =
                                                  cpu_symbol;
                                                btn_enable = true;
                                                used_btn_idexes.push(6);
                                                YouWinDialog(false);
                                              } else {
                                                if (
                                                  buttons_input[2]
                                                    .textContent ==
                                                    cpu_symbol &&
                                                  buttons_input[4]
                                                    .textContent == "" &&
                                                  buttons_input[6]
                                                    .textContent == cpu_symbol
                                                ) {
                                                  buttons_input[4].textContent =
                                                    cpu_symbol;
                                                  btn_enable = true;
                                                  used_btn_idexes.push(4);
                                                  YouWinDialog(false);
                                                } else {
                                                  // Start Defending

                                                  if (
                                                    buttons_input[0]
                                                      .textContent != "" &&
                                                    buttons_input[1]
                                                      .textContent != "" &&
                                                    buttons_input[2]
                                                      .textContent != "" &&
                                                    buttons_input[3]
                                                      .textContent != "" &&
                                                    buttons_input[4]
                                                      .textContent != "" &&
                                                    buttons_input[5]
                                                      .textContent != "" &&
                                                    buttons_input[6]
                                                      .textContent != "" &&
                                                    buttons_input[7]
                                                      .textContent != "" &&
                                                    buttons_input[8]
                                                      .textContent != ""
                                                  ) {
                                                    YouWinDialog(true);
                                                  } else {
                                                    if (
                                                      buttons_input[0]
                                                        .textContent ==
                                                        your_symbol &&
                                                      buttons_input[1]
                                                        .textContent ==
                                                        your_symbol &&
                                                      buttons_input[2]
                                                        .textContent == ""
                                                    ) {
                                                      buttons_input[2].textContent =
                                                        cpu_symbol;
                                                      btn_enable = true;
                                                      used_btn_idexes.push(2);
                                                    } else {
                                                      if (
                                                        buttons_input[1]
                                                          .textContent ==
                                                          your_symbol &&
                                                        buttons_input[2]
                                                          .textContent ==
                                                          your_symbol &&
                                                        buttons_input[0]
                                                          .textContent == ""
                                                      ) {
                                                        buttons_input[0].textContent =
                                                          cpu_symbol;
                                                        btn_enable = true;
                                                        used_btn_idexes.push(0);
                                                      } else {
                                                        if (
                                                          buttons_input[0]
                                                            .textContent ==
                                                            your_symbol &&
                                                          buttons_input[2]
                                                            .textContent ==
                                                            your_symbol &&
                                                          buttons_input[1]
                                                            .textContent == ""
                                                        ) {
                                                          buttons_input[1].textContent =
                                                            cpu_symbol;
                                                          btn_enable = true;
                                                          used_btn_idexes.push(
                                                            1
                                                          );
                                                        } else {
                                                          if (
                                                            buttons_input[3]
                                                              .textContent ==
                                                              your_symbol &&
                                                            buttons_input[4]
                                                              .textContent ==
                                                              your_symbol &&
                                                            buttons_input[5]
                                                              .textContent == ""
                                                          ) {
                                                            buttons_input[5].textContent =
                                                              cpu_symbol;
                                                            used_btn_idexes.push(
                                                              5
                                                            );
                                                            btn_enable = true;
                                                          } else {
                                                            if (
                                                              buttons_input[3]
                                                                .textContent ==
                                                                "" &&
                                                              buttons_input[4]
                                                                .textContent ==
                                                                your_symbol &&
                                                              buttons_input[5]
                                                                .textContent ==
                                                                your_symbol
                                                            ) {
                                                              buttons_input[3].textContent =
                                                                cpu_symbol;
                                                              btn_enable = true;
                                                              used_btn_idexes.push(
                                                                3
                                                              );
                                                            } else {
                                                              if (
                                                                buttons_input[3]
                                                                  .textContent ==
                                                                  your_symbol &&
                                                                buttons_input[4]
                                                                  .textContent ==
                                                                  "" &&
                                                                buttons_input[5]
                                                                  .textContent ==
                                                                  your_symbol
                                                              ) {
                                                                buttons_input[4].textContent =
                                                                  cpu_symbol;
                                                                btn_enable = true;
                                                                used_btn_idexes.push(
                                                                  4
                                                                );
                                                              } else {
                                                                if (
                                                                  buttons_input[6]
                                                                    .textContent ==
                                                                    your_symbol &&
                                                                  buttons_input[7]
                                                                    .textContent ==
                                                                    your_symbol &&
                                                                  buttons_input[8]
                                                                    .textContent ==
                                                                    ""
                                                                ) {
                                                                  buttons_input[8].textContent =
                                                                    cpu_symbol;
                                                                  btn_enable = true;
                                                                  used_btn_idexes.push(
                                                                    8
                                                                  );
                                                                } else {
                                                                  if (
                                                                    buttons_input[7]
                                                                      .textContent ==
                                                                      your_symbol &&
                                                                    buttons_input[8]
                                                                      .textContent ==
                                                                      your_symbol &&
                                                                    buttons_input[6]
                                                                      .textContent ==
                                                                      ""
                                                                  ) {
                                                                    buttons_input[6].textContent =
                                                                      cpu_symbol;
                                                                    btn_enable = true;
                                                                    used_btn_idexes.push(
                                                                      6
                                                                    );
                                                                  } else {
                                                                    if (
                                                                      buttons_input[6]
                                                                        .textContent ==
                                                                        your_symbol &&
                                                                      buttons_input[7]
                                                                        .textContent ==
                                                                        "" &&
                                                                      buttons_input[8]
                                                                        .textContent ==
                                                                        your_symbol
                                                                    ) {
                                                                      buttons_input[7].textContent =
                                                                        cpu_symbol;
                                                                      used_btn_idexes.push(
                                                                        7
                                                                      );
                                                                      btn_enable = true;
                                                                    } else {
                                                                      if (
                                                                        buttons_input[0]
                                                                          .textContent ==
                                                                          your_symbol &&
                                                                        buttons_input[3]
                                                                          .textContent ==
                                                                          your_symbol &&
                                                                        buttons_input[6]
                                                                          .textContent ==
                                                                          ""
                                                                      ) {
                                                                        buttons_input[6].textContent =
                                                                          cpu_symbol;
                                                                        btn_enable = true;
                                                                        used_btn_idexes.push(
                                                                          6
                                                                        );
                                                                      } else {
                                                                        if (
                                                                          buttons_input[0]
                                                                            .textContent ==
                                                                            "" &&
                                                                          buttons_input[3]
                                                                            .textContent ==
                                                                            your_symbol &&
                                                                          buttons_input[6]
                                                                            .textContent ==
                                                                            your_symbol
                                                                        ) {
                                                                          buttons_input[0].textContent =
                                                                            cpu_symbol;
                                                                          btn_enable = true;
                                                                          used_btn_idexes.push(
                                                                            0
                                                                          );
                                                                        } else {
                                                                          if (
                                                                            buttons_input[0]
                                                                              .textContent ==
                                                                              your_symbol &&
                                                                            buttons_input[6]
                                                                              .textContent ==
                                                                              your_symbol &&
                                                                            buttons_input[3]
                                                                              .textContent ==
                                                                              ""
                                                                          ) {
                                                                            buttons_input[3].textContent =
                                                                              cpu_symbol;
                                                                            btn_enable = true;
                                                                            used_btn_idexes.push(
                                                                              3
                                                                            );
                                                                          } else {
                                                                            if (
                                                                              buttons_input[1]
                                                                                .textContent ==
                                                                                your_symbol &&
                                                                              buttons_input[4]
                                                                                .textContent ==
                                                                                your_symbol &&
                                                                              buttons_input[7]
                                                                                .textContent ==
                                                                                ""
                                                                            ) {
                                                                              buttons_input[7].textContent =
                                                                                cpu_symbol;
                                                                              btn_enable = true;
                                                                              used_btn_idexes.push(
                                                                                7
                                                                              );
                                                                            } else {
                                                                              if (
                                                                                buttons_input[1]
                                                                                  .textContent ==
                                                                                  "" &&
                                                                                buttons_input[4]
                                                                                  .textContent ==
                                                                                  your_symbol &&
                                                                                buttons_input[7]
                                                                                  .textContent ==
                                                                                  your_symbol
                                                                              ) {
                                                                                buttons_input[1].textContent =
                                                                                  cpu_symbol;
                                                                                used_btn_idexes.push(
                                                                                  1
                                                                                );
                                                                              } else {
                                                                                if (
                                                                                  buttons_input[1]
                                                                                    .textContent ==
                                                                                    your_symbol &&
                                                                                  buttons_input[4]
                                                                                    .textContent ==
                                                                                    "" &&
                                                                                  buttons_input[7]
                                                                                    .textContent ==
                                                                                    your_symbol
                                                                                ) {
                                                                                  buttons_input[4].textContent =
                                                                                    cpu_symbol;
                                                                                  btn_enable = true;
                                                                                  used_btn_idexes.push(
                                                                                    4
                                                                                  );
                                                                                } else {
                                                                                  if (
                                                                                    buttons_input[2]
                                                                                      .textContent ==
                                                                                      "" &&
                                                                                    buttons_input[5]
                                                                                      .textContent ==
                                                                                      your_symbol &&
                                                                                    buttons_input[8]
                                                                                      .textContent ==
                                                                                      your_symbol
                                                                                  ) {
                                                                                    buttons_input[2].textContent =
                                                                                      cpu_symbol;
                                                                                    btn_enable = true;
                                                                                    used_btn_idexes.push(
                                                                                      2
                                                                                    );
                                                                                  } else {
                                                                                    if (
                                                                                      buttons_input[2]
                                                                                        .textContent ==
                                                                                        your_symbol &&
                                                                                      buttons_input[5]
                                                                                        .textContent ==
                                                                                        your_symbol &&
                                                                                      buttons_input[8]
                                                                                        .textContent ==
                                                                                        ""
                                                                                    ) {
                                                                                      buttons_input[8].textContent =
                                                                                        cpu_symbol;
                                                                                      btn_enable = true;
                                                                                      used_btn_idexes.push(
                                                                                        8
                                                                                      );
                                                                                    } else {
                                                                                      if (
                                                                                        buttons_input[2]
                                                                                          .textContent ==
                                                                                          your_symbol &&
                                                                                        buttons_input[5]
                                                                                          .textContent ==
                                                                                          "" &&
                                                                                        buttons_input[8]
                                                                                          .textContent ==
                                                                                          your_symbol
                                                                                      ) {
                                                                                        buttons_input[5].textContent =
                                                                                          cpu_symbol;
                                                                                        btn_enable = true;
                                                                                        used_btn_idexes.push(
                                                                                          8
                                                                                        );
                                                                                      } else {
                                                                                        if (
                                                                                          buttons_input[0]
                                                                                            .textContent ==
                                                                                            your_symbol &&
                                                                                          buttons_input[4]
                                                                                            .textContent ==
                                                                                            your_symbol &&
                                                                                          buttons_input[8]
                                                                                            .textContent ==
                                                                                            ""
                                                                                        ) {
                                                                                          buttons_input[8].textContent =
                                                                                            cpu_symbol;
                                                                                          btn_enable = true;
                                                                                          used_btn_idexes.push(
                                                                                            8
                                                                                          );
                                                                                        } else {
                                                                                          if (
                                                                                            buttons_input[0]
                                                                                              .textContent ==
                                                                                              "" &&
                                                                                            buttons_input[4]
                                                                                              .textContent ==
                                                                                              your_symbol &&
                                                                                            buttons_input[8]
                                                                                              .textContent ==
                                                                                              your_symbol
                                                                                          ) {
                                                                                            buttons_input[0].textContent =
                                                                                              cpu_symbol;
                                                                                            btn_enable = true;
                                                                                            used_btn_idexes.push(
                                                                                              0
                                                                                            );
                                                                                          } else {
                                                                                            if (
                                                                                              buttons_input[0]
                                                                                                .textContent ==
                                                                                                your_symbol &&
                                                                                              buttons_input[4]
                                                                                                .textContent ==
                                                                                                "" &&
                                                                                              buttons_input[8]
                                                                                                .textContent ==
                                                                                                your_symbol
                                                                                            ) {
                                                                                              buttons_input[4].textContent =
                                                                                                cpu_symbol;
                                                                                              btn_enable = true;
                                                                                              used_btn_idexes.push(
                                                                                                4
                                                                                              );
                                                                                            } else {
                                                                                              if (
                                                                                                buttons_input[2]
                                                                                                  .textContent ==
                                                                                                  "" &&
                                                                                                buttons_input[4]
                                                                                                  .textContent ==
                                                                                                  your_symbol &&
                                                                                                buttons_input[6]
                                                                                                  .textContent ==
                                                                                                  your_symbol
                                                                                              ) {
                                                                                                buttons_input[2].textContent =
                                                                                                  cpu_symbol;
                                                                                                btn_enable = true;
                                                                                                used_btn_idexes.push(
                                                                                                  2
                                                                                                );
                                                                                              } else {
                                                                                                if (
                                                                                                  buttons_input[2]
                                                                                                    .textContent ==
                                                                                                    your_symbol &&
                                                                                                  buttons_input[4]
                                                                                                    .textContent ==
                                                                                                    your_symbol &&
                                                                                                  buttons_input[6]
                                                                                                    .textContent ==
                                                                                                    ""
                                                                                                ) {
                                                                                                  buttons_input[6].textContent =
                                                                                                    cpu_symbol;
                                                                                                  btn_enable = true;
                                                                                                  used_btn_idexes.push(
                                                                                                    6
                                                                                                  );
                                                                                                } else {
                                                                                                  if (
                                                                                                    buttons_input[2]
                                                                                                      .textContent ==
                                                                                                      your_symbol &&
                                                                                                    buttons_input[4]
                                                                                                      .textContent ==
                                                                                                      "" &&
                                                                                                    buttons_input[6]
                                                                                                      .textContent ==
                                                                                                      your_symbol
                                                                                                  ) {
                                                                                                    buttons_input[4].textContent =
                                                                                                      cpu_symbol;
                                                                                                    used_btn_idexes.push(
                                                                                                      4
                                                                                                    );
                                                                                                    btn_enable = true;
                                                                                                  } else {
                                                                                                    // Start Defending
                                                                                                    computerResponse(
                                                                                                      items
                                                                                                    );
                                                                                                  }
                                                                                                }
                                                                                              }
                                                                                            }
                                                                                          }
                                                                                        }
                                                                                      }
                                                                                    }
                                                                                  }
                                                                                }
                                                                              }
                                                                            }
                                                                          }
                                                                        }
                                                                      }
                                                                    }
                                                                  }
                                                                }
                                                              }
                                                            }
                                                          }
                                                        }
                                                      }
                                                    }
                                                  }
                                                }
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}

function Win(items) {
  if (
    buttons_input[0].textContent == current_player &&
    buttons_input[1].textContent == current_player &&
    buttons_input[2].textContent == current_player
  ) {
    YouWinDialog();
  } else {
    if (
      buttons_input[0].textContent == current_player &&
      buttons_input[3].textContent == current_player &&
      buttons_input[6].textContent == current_player
    ) {
      YouWinDialog();
    } else {
      if (
        buttons_input[0].textContent == current_player &&
        buttons_input[4].textContent == current_player &&
        buttons_input[8].textContent == current_player
      ) {
        YouWinDialog();
      } else {
        if (
          buttons_input[1].textContent == current_player &&
          buttons_input[4].textContent == current_player &&
          buttons_input[7].textContent == current_player
        ) {
          YouWinDialog();
        } else {
          if (
            buttons_input[2].textContent == current_player &&
            buttons_input[5].textContent == current_player &&
            buttons_input[8].textContent == current_player
          ) {
            YouWinDialog();
          } else {
            if (
              buttons_input[2].textContent == current_player &&
              buttons_input[4].textContent == current_player &&
              buttons_input[6].textContent == current_player
            ) {
              YouWinDialog();
            } else {
              if (
                buttons_input[6].textContent == current_player &&
                buttons_input[7].textContent == current_player &&
                buttons_input[8].textContent == current_player
              ) {
                YouWinDialog();
              } else {
                if (
                  buttons_input[3].textContent == current_player &&
                  buttons_input[4].textContent == current_player &&
                  buttons_input[5].textContent == current_player
                ) {
                  YouWinDialog();
                } else {
                  if (
                    buttons_input[0].textContent != "" &&
                    buttons_input[1].textContent != "" &&
                    buttons_input[2].textContent != "" &&
                    buttons_input[3].textContent != "" &&
                    buttons_input[4].textContent != "" &&
                    buttons_input[5].textContent != "" &&
                    buttons_input[6].textContent != "" &&
                    buttons_input[7].textContent != "" &&
                    buttons_input[8].textContent != ""
                  ) {
                    YouWinDialog(true);
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}

function YouWinDialog(tie) {
  if (tie) {
    // Show Tie Dialog
    win_msg.textContent = "Game is tie!";
    win_dialog.classList.add("win_dialog_anim");
  } else {
    // Show Win Dialog
    win_msg.textContent =
      "Player " + current_player + " " + "Has Won The Match...";
    win_dialog.classList.add("win_dialog_anim");
  }
}

function computerResponse(items) {
  let cpu_num = Math.floor(Math.random() * 9);
  if (used_btn_idexes.includes(cpu_num)) {
    computerResponse(items);
  } else {
    buttons_input[cpu_num].textContent = cpu_symbol;
    used_btn_idexes.push(cpu_num);
    btn_enable = true;
    Win(items);
  }
}

btn_symbol[0].addEventListener("click", () => {
  your_symbol = "X";
  cpu_symbol = "O";
  dialog.classList.add("dialog_anim");
  console.log("Clicked X");
});

btn_symbol[1].addEventListener("click", (e) => {
  your_symbol = "O";
  cpu_symbol = "X";
  dialog.classList.add("dialog_anim");
  console.log("Clicked O");
});

btn_restart.addEventListener("click", () => {
  win_dialog.classList.remove("win_dialog_anim");
  current_player = your_symbol;
  your_symbol = "";
  cpu_symbol = "";
  btn_enable = true;
  current_player = your_symbol;
  used_btn_idexes = [];
  dialog.classList.remove("dialog_anim");

  buttons_input.forEach((items) => {
    items.textContent = "";
  });

  clearTimeout(cputime);
});
