const btn_play = document.querySelector(".btn_play");
const dialog_container = document.querySelector(".dialog_container");
const container = document.querySelector(".container");
const btns = document.querySelectorAll(".btns");

btn_play.addEventListener("click", () => {
  dialog_container.classList.add("dialog_container_anim");
});

btns.forEach((item, index) => {
  item.addEventListener("click", () => {
    dialog_container.classList.remove("dialog_container_anim");
  });
});

btns[0].addEventListener("click", () => {
  localStorage.setItem("type", "easy");
  document.location.href = "./game.html";
});
btns[1].addEventListener("click", () => {
  localStorage.setItem("type", "hard");
  document.location.href = "./game.html";
});
