const boxMain1 = document.querySelector(".box-main-1");
const boxMain2 = document.querySelector(".box-main-2");
const boxMain3 = document.querySelector(".box-main-3");
const playPauseImg = document.querySelector(".play-pause-img");
const ul_playlists = document.querySelector(".playlists");
const ul_songs = document.querySelector(".songs");
const title_artist = document.querySelector(".artist");
const title_playlist = document.querySelector(".playlist");
const play_pause_btn = document.querySelector(".play-pause");
const main_song_pic = document.querySelector(".main-song-pic");
const song_title_player = document.querySelector(".song_title_player");

playlists.forEach((items) => {
  AddAllPlaylists(items);
});

let playListOpened = false;
let selected_playlist_name = "";
let audio = new Audio();
let is_playing = false;

function AddAllPlaylists(items) {
  const li = document.createElement("LI");
  li.classList.add("item-playlist");
  li.classList.add("items-main");

  const div = document.createElement("DIV");
  div.classList.add("div-item-playlist");

  const img = document.createElement("IMG");
  img.classList.add("img-items");
  img.classList.add("img-playlist");
  img.src = items.thumbnail_url;

  const div2 = document.createElement("DIV");
  div2.classList.add("texts-div-item-playlist");
  div2.classList.add("inner-divs");

  const h4 = document.createElement("H4");
  h4.classList.add("playlist-title-item");
  h4.textContent = items.title;

  const p = document.createElement("P");
  p.classList.add("playlist-desc-item");
  p.classList.add("text-descriptions-items");
  p.textContent = "Click here to get songs";

  ul_playlists.appendChild(li);
  li.appendChild(div);
  div.appendChild(img);
  div.appendChild(div2);
  div2.appendChild(h4);
  div2.appendChild(p);

  li.addEventListener("click", (e) => {
    const li_main = document.querySelectorAll(".item-playlist");
    li_main.forEach((item) => {
      item.classList.remove("active");
    });
    li.classList.add("active");
    LoadAllSongsFromPlaylist(items);
    selected_playlist_name = items.title;
  });
}

async function LoadAllSongsFromPlaylist(items) {
  const respone = await fetch(
    "https://v1.nocodeapi.com/azuddr/spotify/eGrmuDHYPBQQUwLe/playlists?id=" +
      items.id
  );
  const result = await respone.json();

  ul_songs.innerHTML = "";
  result.tracks.items.forEach((item) => {
    boxMain2.style.display = "flex";
    CreateSongs(item);
  });
}

function CreateSongs(song) {
  const li = document.createElement("LI");
  li.classList.add("item-song");
  li.classList.add("items-main");

  const div = document.createElement("DIV");
  div.classList.add("div-item-song");

  const img = document.createElement("IMG");
  img.classList.add("img-items");
  img.classList.add("img-song");
  img.src = song.track.album.images[0].url;

  const div2 = document.createElement("DIV");
  div2.classList.add("texts-div-item-song");
  div2.classList.add("inner-divs");

  const h4 = document.createElement("H4");
  h4.classList.add("song-title-item");
  h4.textContent = song.track.name;

  const p = document.createElement("P");
  p.classList.add("song-desc-item");
  p.classList.add("text-descriptions-items");
  p.textContent = "Click here to Play song...";

  ul_songs.appendChild(li);
  li.appendChild(div);
  div.appendChild(img);
  div.appendChild(div2);
  div2.appendChild(h4);
  div2.appendChild(p);

  if (song.track.name == "" || song.track.name == null) {
    h4.textContent = "Null Name";
    li.enable;
  }

  li.addEventListener("click", (e) => {
    const li_main = document.querySelectorAll(".item-song");
    li_main.forEach((item) => {
      item.classList.remove("active");
    });
    li.classList.add("active");
    audio.src = song.track.preview_url;
    audio.type = "audio/wav";
    playPauseImg.src = "../Assets/play-button-arrowhead.png";
    audio.pause();
    is_playing = false;
    PlaySong(song);
  });

  li.addEventListener("dblclick", () => {
    boxMain3.style.display = "flex";
  });
}

function PlaySong(song) {
  main_song_pic.src = song.track.album.images[0].url;
  song_title_player.textContent = song.track.name;
  title_playlist.textContent = selected_playlist_name;
  let artist = song.track.artists[0].name;
  title_artist.textContent = artist;
  play_pause_btn.addEventListener("click", (e) => {
    PlayMusic(song);
  });
}

async function PlayMusic(song) {
  if (is_playing) {
    is_playing = false;
    playPauseImg.src = "../Assets/play-button-arrowhead.png";
    audio.pause();
  } else {
    try {
      is_playing = true;
      playPauseImg.src = "../Assets/pause.png";
      await audio.play();
    } catch (err) {}
  }
}
