const playlists = [
  {
    thumbnail_url:
      "https://mosaic.scdn.co/640/ab67616d0000b2731dda544f66f0eef95f7168eeab67616d0000b27353a2e11c1bde700722fecd2eab67616d0000b2737704566a51ab17c885221bdeab67616d0000b273dfe6cfcd34e433d548501824",
    title: "Eyes On You X Zara Zara",
    url: "https://v1.nocodeapi.com/azuddr/spotify/eGrmuDHYPBQQUwLe/playlists",
    id: "7cTLq3PLZZKhP4xW445S8x",
  },
  {
    thumbnail_url:
      "https://mosaic.scdn.co/640/ab67616d0000b2736539071e0f1833190a491d4dab67616d0000b273bcb8ec035de7b2dda0f74660ab67616d0000b273c1cd18ce264a99c525dd88f5ab67616d0000b273f7f3feb4c9ea40bae3888d2a",
    title: "Hindi Songs - Viral",
    url: "https://v1.nocodeapi.com/azuddr/spotify/eGrmuDHYPBQQUwLe/playlists",
    id: "5vgJ7nyQI2hG0EMdI2b59N",
  },
];
