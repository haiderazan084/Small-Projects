const input_url = document.querySelector(".input-url");
const btn_download = document.querySelector(".download-video");

btn_download.addEventListener("click", async (e) => {
  e.preventDefault();

  if (input_url.value !== "") {
    downloadImage(input_url.value);
  }
});

function downloadImage(url) {
  var xhr = new XMLHttpRequest();
  xhr.open("GET", url, true);
  xhr.responseType = "blob";
  xhr.onload = function () {
    var urlCreator = window.URL || window.webkitURL;
    var imageUrl = urlCreator.createObjectURL(this.response);
    var tag = document.createElement("a");
    tag.href = imageUrl;
    tag.target = "_blank";
    tag.download = "sample";
    document.body.appendChild(tag);
    tag.click();
    document.body.removeChild(tag);
  };
  xhr.onerror = (err) => {
    alert("Failed to download picture");
  };
  xhr.send();
}
