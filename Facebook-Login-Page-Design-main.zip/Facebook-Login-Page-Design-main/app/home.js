let lis = document.getElementsByClassName("items");
li = Array.from(lis);
li.reverse();
