let users = [
  {
    email: "developersddr@gmail.com",
    number: "03555277441",
    password: "azuKing@",
  },
  {
    email: "abcd@gmail.com",
    number: "03462976588",
    password: "abcdefghi",
  },
  {
    email: "azan@gmail.com",
    number: "03464747891",
    password: "12345678",
  },
  {
    email: "rumail@gmail.com",
    number: "03545237461",
    password: "rumail@gm",
  },
  {
    email: "azan@.",
    number: "03545237461",
    password: "123456",
  },
];

let enterEmail = document.querySelector("#editEmail");
let editPassword = document.querySelector("#editPassword");
let errorPasswordMsg = document.querySelector("#errorPasswordMsg");
let errorEmailMsg = document.querySelector("#errorEmailMsg");
let buttonLogin = document.querySelector("#buttonLogin");
let btnAddAccount = document.querySelector(".addAccount");
// Forms Ids
let formEmail = document.querySelector("#formEmail");
let formPassword = document.querySelector("#formPassword");

let email = false,
  password = false;

btnAddAccount.addEventListener("click", () => {
  window.location.href = "../screens/addaccount.html";
});
formEmail.addEventListener("focusout", () => {
  if (!enterEmail.value.includes("@") || !enterEmail.value.includes(".")) {
    if (!Number.isInteger(Number(enterEmail.value))) {
      errorEmailMsg.style.display = "block";
      email = false;
    } else {
      errorEmailMsg.style.display = "none";
      email = true;
    }
  } else {
    errorEmailMsg.style.display = "none";
    email = true;
  }
});

formPassword.addEventListener("focusout", () => {
  if (editPassword.value == "") {
    errorPasswordMsg.style.display = "none";
  } else {
    if (editPassword.value.length > 30) {
      errorPasswordMsg.textContent =
        "Seems like, the password you have entered is greater then 30 characters! Make sure that passwords greater then 30 characters are not allowed";
      errorPasswordMsg.style.display = "block";
      password = false;
    } else {
      if (editPassword.value.length < 6) {
        errorPasswordMsg.textContent =
          "Seems like, the password you have entered is less then 6 characters!";
        errorPasswordMsg.style.display = "block";
        password = false;
      } else {
        errorPasswordMsg.style.display = "none";
        password = true;
      }
    }
  }
});

buttonLogin.addEventListener("click", function () {
  if (
    email &&
    password &&
    !enterEmail.value == "" &&
    !editPassword.value == ""
  ) {
    LoginAccount();
  }
});

function LoginAccount() {
  for (let a = 0; a < users.length; a++) {
    if (
      users[a].email == enterEmail.value ||
      users[a].number == enterEmail.value
    ) {
      if (users[a].password == editPassword.value) {
        window.location.href = "../screens/home.html";
        break;
      }
    }
  }
}
