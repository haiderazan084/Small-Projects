const btn_generate = document.querySelector(".btn_generate");
const input_url = document.querySelector(".input_url");
const card_div2 = document.querySelector(".card_div2");
const qr_code = document.querySelector(".qr_code");
const btn_download = document.querySelector(".btn_download");
const qr_code_div = document.querySelector(".qr_code_div");

btn_generate.addEventListener("click", () => {
  // Generate QR-Code
  let url = input_url.value;

  if (!url) {
    return true;
  } else {
    btn_generate.value = "Qr Code Is Generating";

    qr_code.src = `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${url}`;

    qr_code.addEventListener("load", () => {
      qr_code.classList.add("active");
      card_div2.classList.add("active");
      btn_download.classList.add("active");
      btn_generate.value = "Generate";
    });
  }
});

btn_download.addEventListener("click", async () => {
  let date = new Date();
  let nameOfDownload =
    "QrCode" + " " + date.toDateString() + " " + date.getSeconds() + ".png";

  const response = await fetch(qr_code.src);

  const blobImage = await response.blob();

  const href = URL.createObjectURL(blobImage);

  const anchorElement = document.createElement("a");
  anchorElement.href = href;
  anchorElement.download = nameOfDownload;

  document.body.appendChild(anchorElement);
  anchorElement.click();

  document.body.removeChild(anchorElement);
  window.URL.revokeObjectURL(href);
});
