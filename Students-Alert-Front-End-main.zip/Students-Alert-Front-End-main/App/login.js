const input_email = document.querySelector(".input_email");
const input_password = document.querySelector(".input_password");
const error_email = document.querySelector(".error_email");
const error_password = document.querySelector(".error_password");
const btn_login = document.querySelector(".btn_login");
const google_login = document.querySelector(".google_login");

let email_setup = false;
let password_setup = false;

input_email.addEventListener("blur", () => {
  if (!input_email.value.includes("@")) {
    if (isNaN(Number(input_email.value)) || input_email.value == "") {
      error_email.classList.add("error_msg_anim");
      email_setup = false;
    } else {
      email_setup = true;
    }
  } else {
    email_setup = true;
  }
});

input_email.addEventListener("input", () => {
  if (input_email.value.includes("@") || !isNaN(Number(input_email.value))) {
    error_email.classList.remove("error_msg_anim");
  } else {
    error_email.classList.add("error_msg_anim");
  }
});

input_password.addEventListener("blur", () => {
  if (input_password.value.length > 16 || input_password.value.length < 8) {
    error_password.classList.add("error_msg_anim");
  } else {
    error_password.classList.remove("error_msg_anim");
    password_setup = true;
  }
});
input_password.addEventListener("input", () => {
  if (input_password.value.length > 16 || input_password.value.length < 8) {
    error_password.classList.add("error_msg_anim");
  } else {
    error_password.classList.remove("error_msg_anim");
    password_setup = true;
  }
});

btn_login.addEventListener("click", () => {
  if (password_setup && email_setup) {
    // Login Account...
  }
});

google_login.addEventListener("click", () => {
  // Login With Google
});
