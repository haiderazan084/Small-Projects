const input_first_name = document.querySelector(".input_first_name");
const input_last_name = document.querySelector(".input_last_name");
const error_name = document.querySelector(".error_name");
const input_email = document.querySelector(".input_email");
const error_email = document.querySelector(".error_email");
const input_number = document.querySelector(".input_number");
const error_number = document.querySelector(".error_number");
const input_password = document.querySelector(".input_password");
const error_password = document.querySelector(".error_password");
const input_password_again = document.querySelector(".input_password_again");
const error_password_again = document.querySelector(".error_password_again");
const error_accept_privacy = document.querySelector(".error_accept_privacy");
const btn_signup = document.querySelector(".btn_signup");

let name = false;
let email = false;
let number = false;
let password = false;
let privacy_policy = false;

input_first_name.addEventListener("blur", () => {
  if (input_first_name.value == "" || input_first_name.value.length > 20) {
    // Show Error
    error_name.classList.add("error_msg_anim");
    name = false;
  } else {
    // Remove Error.
    error_name.classList.remove("error_msg_anim");
    name = true;
  }
});

input_first_name.addEventListener("input", (e) => {
  console.log("Typing");

  if (input_first_name.value.length > 20) {
    error_name.classList.add("error_msg_anim");
  } else {
    error_name.classList.remove("error_msg_anim");
  }
});

input_last_name.addEventListener("blur", () => {
  if (input_first_name.value == "") {
    name = false;
    error_name.classList.add("error_msg_anim");
  } else {
    error_name.classList.remove("error_msg_anim");
  }
});

input_email.addEventListener("input", () => {
  if (!input_email.value.includes("@")) {
    error_email.classList.add("error_msg_anim");
  } else {
    error_email.classList.remove("error_msg_anim");
  }
});

input_email.addEventListener("blur", () => {
  if (input_email.value == "" || !input_email.value.includes("@")) {
    error_email.classList.add("error_msg_anim");
    email = false;
  } else {
    email = true;
    error_email.classList.remove("error_msg_anim");
  }
});
input_number.addEventListener("input", () => {
  if (input_number.value == "" || isNaN(Number(input_number.value))) {
    error_number.classList.add("error_msg_anim");
  } else {
    error_number.classList.remove("error_msg_anim");
  }
});

input_number.addEventListener("blur", () => {
  if (input_number.value == "" || isNaN(Number(input_number.value))) {
    error_number.classList.add("error_msg_anim");
    number = false;
  } else {
    number = true;
    error_number.classList.remove("error_msg_anim");
  }
});

input_password.addEventListener("blur", () => {
  if (input_password.value.length > 16 || input_password.value.length < 8) {
    error_password.classList.add("error_msg_anim");
    password = true;
  } else {
    error_password.classList.remove("error_msg_anim");
    password = true;
  }
});

input_password.addEventListener("input", () => {
  if (input_password.value.length > 16 || input_password.value.length < 8) {
    error_password.classList.add("error_msg_anim");
  } else {
    error_password.classList.remove("error_msg_anim");
  }
});

input_password_again.addEventListener("blur", () => {
  if (input_password.value == input_password_again.value) {
    error_password_again.classList.remove("error_msg_anim");
  } else {
    error_password_again.classList.add("error_msg_anim");
  }
});

btn_signup.addEventListener("click", () => {
  if (name && password) {
    if (email || number) {
      // Signup
    }
  }
});
