const img_drawer = document.querySelector(".img-drawer");
const drawer = document.querySelector(".drawer");
const main_drawer = document.querySelector(".main_drawer");
const header = document.querySelector(".header-div");

window.addEventListener("scroll", (e) => {
  if (window.scrollY < 2) {
    header.classList.remove("header-scrolled");
  } else {
    header.classList.add("header-scrolled");
  }
});

img_drawer.addEventListener("click", () => {
  drawer.classList.add("drawer_open");
  main_drawer.classList.add("main_drawer_open");
  console.log("clicked");
});

drawer.addEventListener("click", () => {
  drawer.classList.remove("drawer_open");
  main_drawer.classList.remove("main_drawer_open");
});
